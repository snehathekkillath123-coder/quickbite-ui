#!/bin/sh
# Deploys the QuickBite pages into Kubernetes and loads the default restaurants.
set -e
cd "$(dirname "$0")"
kubectl get namespace foodapp >/dev/null

kubectl create configmap quickbite-ui-files -n foodapp \
  --from-file=index.html --from-file=admin.html --from-file=config.js=config.k8s.js \
  --dry-run=client -o yaml | kubectl apply -f -

kubectl delete job quickbite-seed -n foodapp --ignore-not-found
kubectl apply -f k8s/
kubectl rollout restart deployment quickbite-ui -n foodapp
kubectl rollout status deployment quickbite-ui -n foodapp --timeout=180s
kubectl wait --for=condition=complete job/quickbite-seed -n foodapp --timeout=180s

echo ""
echo "Done. Open the site with:"
echo "  minikube service quickbite-ui -n foodapp --url"
echo "(keep that Terminal window open; add /admin.html to the address for the admin page)"
