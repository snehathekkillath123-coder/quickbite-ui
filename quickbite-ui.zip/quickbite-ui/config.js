// Where the two QuickBite services are running.
// If the minikube tunnel ports change, edit these two lines and refresh the page.
window.QB_CONFIG = {
  restaurantUrl: "http://127.0.0.1:62455",
  orderUrl: "http://127.0.0.1:62481"
};
