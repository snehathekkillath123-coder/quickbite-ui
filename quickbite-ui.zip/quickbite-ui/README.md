# quickbite-ui

Customer page (`index.html`) and admin page (`admin.html`) for QuickBite.
Runs as a third container (nginx) in the same Kubernetes namespace. nginx forwards
`/restaurant/...` to restaurant-service and `/order/...` to order-service, so the pages
need no CORS settings and no service addresses.

## Deploy
    sh deploy.sh
    minikube service quickbite-ui -n foodapp --url      # keep this window open

Add `/admin.html` to the printed address for the admin page.

`deploy.sh` also runs a one-time Job (`k8s/seed-job.yaml`, same commands as `seed.sh`) that adds the
default restaurants and dishes. It is safe to run again; it never creates duplicates.

## Without Kubernetes
Open `index.html` directly and edit the two addresses in `config.js`
(this needs CORS enabled on both services).
