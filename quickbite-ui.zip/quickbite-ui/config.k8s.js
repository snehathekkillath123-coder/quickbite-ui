// Used when the pages run inside Kubernetes: same address as the page, nginx forwards to the services.
window.QB_CONFIG = {
  restaurantUrl: "/restaurant",
  orderUrl: "/order"
};
