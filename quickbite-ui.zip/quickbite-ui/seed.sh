BASE=${BASE:-http://restaurant-service:8081/api}
JSON='Content-Type: application/json'

echo "Waiting for restaurant-service..."
until curl -sf "$BASE/restaurants" >/dev/null; do sleep 3; done

# id of a restaurant by exact name (empty if missing)
rid() { curl -s "$BASE/restaurants" | tr '}' '\n' | grep "\"name\":\"$1\"" | head -1 | sed 's/.*"id":\([0-9]*\).*/\1/'; }

restaurant() { # name cuisine address -> sets RID
  RID=$(rid "$1")
  if [ -z "$RID" ]; then
    curl -s -X POST "$BASE/restaurants" -H "$JSON" -d "{\"name\":\"$1\",\"cuisine\":\"$2\",\"address\":\"$3\"}" >/dev/null
    RID=$(rid "$1")
    echo "added restaurant $1 (id $RID)"
  else
    echo "restaurant $1 already exists (id $RID)"
  fi
}

dish() { # name price (uses RID)
  if ! curl -s "$BASE/restaurants/$RID/menu" | grep -q "\"name\":\"$1\""; then
    curl -s -X POST "$BASE/restaurants/$RID/menu" -H "$JSON" -d "{\"name\":\"$1\",\"price\":$2}" >/dev/null
  fi
}

restaurant "Spice Hub" "Indian" "Boston"
dish "Paneer Tikka" 9.50; dish "Butter Chicken" 12.00; dish "Veg Biryani" 10.50; dish "Garlic Naan" 2.25; dish "Mango Lassi" 3.50

restaurant "Luigi's Trattoria" "Italian" "Cambridge"
dish "Margherita Pizza" 11.00; dish "Spaghetti Carbonara" 13.50; dish "Lasagna" 12.50; dish "Garlic Bread" 4.50; dish "Tiramisu" 6.00

restaurant "Dragon Wok" "Chinese" "Somerville"
dish "Veg Noodles" 9.00; dish "Kung Pao Chicken" 12.50; dish "Veg Dumplings" 7.50; dish "Fried Rice" 8.50; dish "Hot and Sour Soup" 5.00

restaurant "Taco Fiesta" "Mexican" "Brookline"
dish "Chicken Tacos" 9.50; dish "Veg Burrito" 10.00; dish "Loaded Nachos" 7.50; dish "Churros" 5.50; dish "Fresh Lime Soda" 3.50

restaurant "Sakura Sushi" "Japanese" "Boston"
dish "Salmon Sushi Roll" 14.00; dish "Veg Ramen" 12.50; dish "Miso Soup" 4.00; dish "Tempura Prawns" 11.00

restaurant "Burger Barn" "Burgers" "Allston"
dish "Classic Cheeseburger" 10.50; dish "Crispy Chicken Burger" 11.00; dish "Loaded Fries" 6.50; dish "Chocolate Milkshake" 5.50; dish "Vanilla Ice Cream" 4.50

restaurant "Sunrise Cafe" "Cafe" "Boston"
dish "Cappuccino" 4.50; dish "Masala Chai" 3.50; dish "Blueberry Pancakes" 8.50; dish "Chocolate Brownie" 5.00; dish "Avocado Sandwich" 9.00

echo "Seeding finished."
